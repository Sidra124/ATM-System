﻿using System;
using EMS_View;
namespace Atm_System
{
    class Program
    {
        static void Main(string[] args)
        {


        }
    }
}
