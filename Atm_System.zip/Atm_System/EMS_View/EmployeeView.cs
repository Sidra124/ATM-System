﻿using System;
using System.Collections.Generic;
using System.Text;
using EMS_BLL;
using EMS_BO;


namespace EMS_View
{
    public class EmployeeView
    {
        EmployeeBO bo = new EmployeeBO();

        public void takeInput()
        {
            int pin;
            Console.WriteLine("Enter your ID: ");
            string id = Console.ReadLine();
            if (id == "Admin")
            {
                Console.WriteLine("Enter a 5-Digit PIN: ");
                pin = System.Convert.ToInt32(Console.ReadLine());
                if (pin == 10000)
                {
                    Administration_Menu();
                }

                else
                {
                    Console.WriteLine("Wrong PIN");
                }

            }

            else
            {
                EmployeeBLL bl = new EmployeeBLL();
                EmployeeBO checkID = bl.getAccount(id);
                bo = checkID;
                if (checkID == null)
                {
                    Console.WriteLine("Account not exist");
                }
                else
                {
                    do
                    {
                        Console.WriteLine("Enter a 5-Digit PIN: ");
                        pin = System.Convert.ToInt32(Console.ReadLine());
                        EmployeeBLL boo = new EmployeeBLL();
                        EmployeeBO checkpin = boo.getPIN(pin);
                        if (checkpin == null)
                        {
                            Console.WriteLine("Enter PIN Again: ");
                            pin = System.Convert.ToInt32((Console.ReadLine()));
                            EmployeeBLL boo1 = new EmployeeBLL();
                            EmployeeBO checkpin1 = boo1.getPIN(pin);
                            if (checkpin1 == null)
                            {
                                Console.WriteLine("Enter PIN One more time: ");
                                pin = System.Convert.ToInt32((Console.ReadLine()));
                                EmployeeBLL boo2 = new EmployeeBLL();
                                EmployeeBO checkpin2 = boo2.getPIN(pin);
                                if (checkpin2 == null)
                                {
                                    Disable();
                                }

                                else
                                {
                                    Customer_Menu();
                                }
                            }

                            else
                            {
                                Customer_Menu();
                            }

                        }
                        else
                        {
                            Customer_Menu();
                        }


                    } while (pin < 10000);

                }

            }

        }


        public void Administration_Menu()
        {

            Console.WriteLine("1---Create New Account.");
            Console.WriteLine("2---Delete Existing Account.");
            Console.WriteLine("3---Update Account Information.");
            Console.WriteLine("4---Search For Account.");
            Console.WriteLine("5---View Reports.");
            Console.WriteLine("6---Exit.");
            int input = System.Convert.ToInt32(Console.ReadLine());
            EmployeeBLL bl = new EmployeeBLL();
            if (input == 1)
                Create_New();
            if (input == 2)
                Delete_Existing();
            if (input == 3)
                Update_Account();
            if (input == 4)
                Search_For();
            if (input == 5)
                View_Repo();
            if (input == 6)
                Exit();

        }

        public void Create_New()
        {
            EmployeeBO bo1 = new EmployeeBO();
            Console.WriteLine("Enter Login: ");
            string login = Console.ReadLine();
            bo1.Login = login;
            Console.WriteLine("Enter PIN: ");
            int pin = System.Convert.ToInt32(Console.ReadLine());
            bo1.PIN = pin;
            Console.WriteLine("Holder Name: ");
            bo1.HName = Console.ReadLine();
            Console.WriteLine("Type (Saving, Current): ");
          bo1.Type = Console.ReadLine();
            Console.WriteLine("Enter Starting Balance: ");
            bo1.Blnc = System.Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Status: ");
           bo1.Status = Console.ReadLine();
            //EmployeeBO bo = new EmployeeBO { Login = login, PIN = pin, Name = Hname, Type = type, Blnc = blnc, Status = status };
            EmployeeBLL bll = new EmployeeBLL();
            Console.WriteLine("Account Successfully Created - The Account Number assigned is: ");
            bll.Create_New_Account(bo1);

        }


        public void Delete_Existing()
        {
            Console.WriteLine("Enter the Account No. to which you want to delete: ");
            int account_no = System.Convert.ToInt32(Console.ReadLine());
            EmployeeBLL bl = new EmployeeBLL();
            EmployeeBO bo2 = bl.getAccount1(account_no);
            if (bo2 != null)
            {
                Console.WriteLine($"You wish to delete the account held by {bo2.HName} , If this information is correct please re-enter the Account No. :");
                int accNo = System.Convert.ToInt32(Console.ReadLine());
                EmployeeBO bo = new EmployeeBO { Account_no = account_no, };
                EmployeeBLL bll = new EmployeeBLL();
                bll.Delete_Existing_Account(account_no, accNo);
            }

        }


        public void Update_Account()
        {
            Console.WriteLine("Enter the Account No. : ");
            int account_no = System.Convert.ToInt32(Console.ReadLine());
            EmployeeBO bo = new EmployeeBO { Account_no = account_no };
            EmployeeBLL bll = new EmployeeBLL();
            bll.Update_Account_Information(bo);

        }



        public void Search_For()
        {
            Console.WriteLine("Search Menu: ");
            Console.WriteLine("Account ID: ");
            int account_id = System.Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("User ID: ");
            int user_id = System.Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Holder Nmae: ");
            string hname = Console.ReadLine();
            Console.WriteLine("Type (Saving, Current): ");
            string type = Console.ReadLine();
            Console.WriteLine("Enter Starting Balance: ");
            int blnc = System.Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Status: ");
            string status = Console.ReadLine();
            EmployeeBLL bll = new EmployeeBLL();
            EmployeeBO bo = new EmployeeBO { HName = hname, Type = type, Blnc = blnc, Status = status };
            bll.Search_For_Account(bo);


        }


        public void View_Repo()
        {
            Console.WriteLine("1---Accounts By Amount.");
            Console.WriteLine("2---Accounts By Date.");
            int input = System.Convert.ToInt32(Console.ReadLine());
            EmployeeBO bo = new EmployeeBO();
            EmployeeBLL bll = new EmployeeBLL();
            bll.View_Reports(bo);
        }


        public void Exit()
        {
            EmployeeBLL bll = new EmployeeBLL();
            bll.Exit();
        }

        //----------------------------------------------------------------------------


        public void Customer_Menu()
        {
            Console.WriteLine("1---Withdraw Cash.");
            Console.WriteLine("2---Cash Transfer.");
            Console.WriteLine("3---Depsit Cash.");
            Console.WriteLine("4---Display Balance.");
            Console.WriteLine("5---Exit.");

            Console.WriteLine("Please Select one of the above options..");

            int input = System.Convert.ToInt32(Console.ReadLine());
            EmployeeBO bo = new EmployeeBO();
            if (input == 1)
                WithdrawCash();
            if (input == 2)
                CashTransfer();
            if (input == 3)
                DepositCash();
            if (input == 4)
                DisplayBalance();
            if (input == 5)
                Exit();
        }


        public void WithdrawCash()
        {
            Console.WriteLine("a) Fast Cash.");
            Console.WriteLine("b) Normal Cash.");
            Console.WriteLine("Please Select a mode of withdrawl:");
            char Input = System.Convert.ToChar(Console.ReadLine());
           
            if (Input == 'a')
            {
                Fast_Cash();

            }

            else if (Input == 'b')
            {
                Normal_Cash();
            }
            else
                Console.WriteLine("Invalid Entry.");

            EmployeeBO bo = new EmployeeBO();
            EmployeeBLL bll = new EmployeeBLL();

        }


        public void CashTransfer()
        {
            int amount;
            Console.WriteLine("Enter the Amount in multiples of 500: ");
            do
            {
                amount = System.Convert.ToInt32(Console.ReadLine());
            } while (amount % 5 == 0);

            Console.WriteLine("Enter the Account number to which you want to transfer: ");
            int account_no = System.Convert.ToInt32(Console.ReadLine());
            EmployeeBLL bl = new EmployeeBLL();
            EmployeeBO bo2 = bl. getAccount1(account_no);
     
            Console.WriteLine("You wish to deposit " + amount + "in account held by " + bo2.HName + "; If this information is correct please re-enter the Account No. :");
            int acc_no = System.Convert.ToInt32(Console.ReadLine());


        }


        public void DepositCash()
        {
            Console.WriteLine("Enter the Cash Amount to deposit: ");
            int amount = System.Convert.ToInt32(Console.ReadLine());

        }


        public void Fast_Cash()
        {
            Console.WriteLine("1---500");
            Console.WriteLine("2---1000");
            Console.WriteLine("3---2000");
            Console.WriteLine("4---5000");
            Console.WriteLine("5---10000");
            Console.WriteLine("6---15000");
            Console.WriteLine("7---20000");
            Console.WriteLine("Select one of the dominations of money: ");
            int choice = System.Convert.ToInt32(Console.ReadLine());
            EmployeeBLL BL = new EmployeeBLL();
            //double blnc = BL.getBlnc(id, pin);
            Console.WriteLine("Are u sure you want to withdraw (Y/N)?: ");
            string ans = Console.ReadLine();
            if (ans == "Y" || ans == "y")
            {
                if (EmployeeBLL.FastCash(bo, choice, bo.Blnc))
                {
                    Console.WriteLine("Cash Successfully Withdrawn!");
                    Console.WriteLine("Do u want to print a receipt(Y/N)?");
                    char C = System.Convert.ToChar(Console.ReadLine());
                    if (C == 'Y' || C == 'y')
                    {

                       // Console.WriteLine(s);
                    }
                }

            }
            else
                Console.WriteLine("Transaction not performed!");

        }


        public void Normal_Cash()
        {
            Console.WriteLine("Enter the withdrawl Amount: ");
            decimal amount = System.Convert.ToInt32(Console.ReadLine());
            EmployeeBLL Bl = new EmployeeBLL();
            //double blnc = Bl.getBlnc(id, pin);
            if(EmployeeBLL.NormalCash(bo.ID,amount, bo.Blnc))
            {
                Console.WriteLine("Cash Successfully Withdrawn!");
                Console.WriteLine("Do you wish to print a receipt?(Y/N)");
                char C = System.Convert.ToChar(Console.ReadLine());
                if (C == 'Y' || C == 'y')
                {
                    PrintRe(amount);
                   
                }
            }

        }
        public void PrintRe(decimal amount)
        {

        }

        public void DisplayBalance()
        {

            
            Console.WriteLine("Account No. : ");
            Console.WriteLine("Date: ");
            Console.WriteLine("Balance: ");


        }

        public void Disable()
        {
            Console.WriteLine("Account Disabled.");
        }
    }

}

