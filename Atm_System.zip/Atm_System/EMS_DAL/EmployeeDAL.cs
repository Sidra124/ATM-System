﻿using EMS_BO;
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace EMS_DAL
{
    public class EmployeeDAL : basedal
    {
        EmployeeBO A = new EmployeeBO();

        public static void SaveAccount(EmployeeBO bo)
        {
            string text = $"{bo.ID},{bo.HName},{bo.Login},{bo.PIN},{bo.Blnc},{bo.Type},{bo.Status}";
            EmployeeDAL da = new EmployeeDAL();
            da.Save(text, "EmployeeData.csv");
        }

        public List<EmployeeBO> ReadEmployee()
        {
            List<String> stringList = Read("EmployeeData.csv");
            List<EmployeeBO> empList = new List<EmployeeBO>();
            foreach (string s in stringList)
            {

                string[] data = s.Split(",");
                EmployeeBO e = new EmployeeBO();

                e.ID = System.Convert.ToInt32(data[0]);
                e.HName = data[1];
                
                e.Login = data[2];
                e.PIN = System.Convert.ToInt32(data[3]);

                e.Blnc = System.Convert.ToDecimal(data[5]);
                e.Type = data[4];
                e.Status = data[6];


                empList.Add(e);
            }



            return empList;

        }

        public static string Encryption(string text)

        {
            string s = "";

            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] >= 'a' && text[i] <= 'z')
                {
                    int val = text[i] - 'z' + 1;
                    val = val + 96;
                }
                if (text[i] >= 'A' && text[i] <= 'Z')

                {
                    int val = text[i] - 'Z' + 1;
                    val = val + 64;
                }
                if (text[i] >= '0' && text[i] <= '9')

                {
                    int val = text[i] - '0' + 1;
                    val = val + 47;
                }

                s += text[i];
            }
            return s;

        }

        public static void writeFunc(List<EmployeeBO> list, string filename)
        {
            string Fpath = Path.Combine(Environment.CurrentDirectory, filename);
            FileStream fs = new FileStream(Fpath, FileMode.Create, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            List<string> Clist = new List<string>();
            if (filename == "AccountData.csv")
            {
                for (int i = 0; i < list.Count; i++)
                {
                    EmployeeDAL ed = new EmployeeDAL();
                   

                    list[i].PIN = System.Convert.ToInt32(Encryption(list[i].PIN.ToString()));
                    list[i].Login = Encryption(list[i].Login);
                    SaveAccount(list[i]);
                   
                }
            }
        }

        private static string GetDecLogin(string[] data)
        {

            return Encryption(data[2]);
        }



        public int CreateAcc(EmployeeBO bo)
        {
            List<EmployeeBO> list = ReadEmployee();
            //string[] data = list[list.Count -1];
            bo.ID = list[list.Count - 1].ID + 1;
          
            list.Add(bo);
            string text = $"{bo.ID},{bo.HName},{bo.Login},{bo.PIN},{bo.Blnc},{bo.Type},{bo.Status}";
           
            writeFunc(list, "AccountData.csv");
            return bo.ID;
        }



        public void DeleteAcc(int accountNumber)
        {
            List<EmployeeBO> list = ReadEmployee();

            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].ID == accountNumber)
                    list.Remove(list[i]);
            }

            writeFunc(list, "AccountData.csv");
        }


           

            //----------------------------------------------------------------------------------


            public string Deposit_Cash(decimal amount, int accNo)
            {
                int ACCNo = 0;
                decimal balance = 0;
                List<EmployeeBO> list = ReadEmployee();
                List<string> transactionList = Read("Transaction.csv");

                for (int i = 0; i < list.Count; i++)
                {
                   

                  
                    if (list[i].ID == accNo)
                        list[i].Blnc += amount;
                    // balance+= amount;
                  

                }

                string s = $"{ACCNo},{DateTime.Now.ToString("dd/MM/YYYY")},Deposit,{amount},{balance}";
                transactionList.Add(s);

                writeFunc(list, "AccountData.csv");
                writeTras(transactionList);
                return s;
            }

            public void writeTras(List<string> list)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    Save(list[i], "Transaction.csv");

                }
            }

            public void Cash_Transfer(decimal amount, int accountNumber, int accountNum2)
            {
                int ACCNo = 0;
                double balance = 0;
                List<EmployeeBO> list = ReadEmployee();
                List<string> transactionList = Read("Transaction.csv");

                for (int i = 0; i < list.Count; i++)
                {

                   
                    if (accountNumber == list[i].ID)
                        list[i].Blnc -= amount;
                    else if (accountNum2 == list[i].ID)
                        list[i].Blnc += amount;
                   
                    
                    if (list[i].ID == accountNumber)
                    {
                        
                        
                        string s = $"{ACCNo},{DateTime.Now.ToString("dd/MM/YYYY")}, Withdraw,{amount},{balance}";
                        transactionList.Add(s);
                    }
                    else if (list[i].ID == accountNum2)
                    {

                        string s = $"{ACCNo},{DateTime.Now.ToString("dd/MM/YYYY")}, Deposit,{amount},{balance}";
                        transactionList.Add(s);
                    }
                }

                writeFunc(list, "AccountData.csv");
                writeTras(transactionList);

            }



            public string Search_for(int accountNumber)
            {
                List<string> list = Read("AccountData.csv");

                for (int i = 0; i < list.Count; i++)
                {
                    string[] data = list[i].Split(",");

                    if (System.Convert.ToInt32(data[0]) == accountNumber)
                    {
                        return list[i];
                    }
                }
                return null;
            }


            public void Fast_cash(int accNo, decimal amount)
            {
                int ACCNo = 0;
                List<EmployeeBO> list = ReadEmployee();
                List<string> transactionList = Read("Transaction.csv");
                decimal balance = 0;
                for (int i = 0; i < list.Count; i++)
                {
                   
                    if (accNo == list[i].ID)
                        balance = list[i].Blnc -= amount;
                    
                }

                string s = $"{ACCNo},{DateTime.Now.ToString("dd/MM/YYYY")}, Withdraw,{amount},{balance}";
                transactionList.Add(s);
                writeFunc(list, "AccountData.csv");
                writeTras(transactionList);
            }


            public void Normal_cash(int accountNo, decimal amount)
            {
                int ACCNo = 0;
                List<EmployeeBO> list = ReadEmployee();
                List<string> transactionList = Read("Transaction.csv");
                decimal balance = 0;
                for (int i = 0; i < list.Count; i++)
                {
                   
                    if (accountNo == list[i].ID)
                        balance = list[i].Blnc -= amount;
                }

                string s = $"{ACCNo},{DateTime.Now.ToString("dd/MM/YYYY")}, Withdraw, {amount},{balance}";
                transactionList.Add(s);


                writeFunc(list, "AccountData.csv");
                writeTras(transactionList);
            }

            public void delete()
            {

             }

    }
}
