﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using EMS_BO;

namespace EMS_DAL
{
    public class basedal
    {
        internal void Save(string text, string filename)
        {
            string filepath = Path.Combine(Environment.CurrentDirectory, filename);
            StreamWriter sw = new StreamWriter(filepath, append: true);
            sw.WriteLine(text);
            sw.Close();

        }

        public List<string> Read(string filename)
        {

            List<string> list = new List<string>();
            string filepath = Path.Combine(Environment.CurrentDirectory,filename);
            StreamReader sr = new StreamReader(filepath);
            string line = string.Empty;
            while ((line = sr.ReadLine()) != null)
            {

                list.Add(line);

            }
            return list;
        }

    }
}