﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EMS_BO
{
    public class EmployeeBO
    {
        public int ID { get; set; }
       // public string Name { get; set; }
        public string HName { set; get; }
        //public int Age { get; set; }
        // decimal Salary { get; set; }

        public int PIN { set; get; }
        public string Login { set; get; }
        public string Type { set; get; }
        public decimal Blnc { set; get; }
        public string Status { set; get; }
         public int Account_no { set; get; }
        // public int Account_id { set; get; }
        //public int User_id { set; get; }
        // public char input { set; get; }
         public int Input { set; get; }
        //public int Amount { get; set; }

    }
}
