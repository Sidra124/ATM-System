﻿using EMS_BO;
using EMS_DAL;
using System;
using System.Collections.Generic;
using System.Text;

namespace EMS_BLL
{
   public  class EMSBll
    {
        EmployeeBO bo = new EmployeeBO();
        EmployeeDAL da = new EmployeeDAL();
    }
}
