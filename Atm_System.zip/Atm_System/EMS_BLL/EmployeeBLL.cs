﻿using EMS_BO;
using EMS_DAL;
using System;
using System.Collections.Generic;
using System.Text;

namespace EMS_BLL
{
    public class EmployeeBLL
    {
        EmployeeBO b = new EmployeeBO();
        public EmployeeBO getAccount(string login)
        {
            EmployeeDAL da = new EmployeeDAL();
            List<EmployeeBO> list = da.ReadEmployee();
            foreach (EmployeeBO bo in list)
                if (bo.Login == login)
                    return bo;
            return null;

        }
        public EmployeeBO getAccount1(int acNO)
        {
            EmployeeDAL da = new EmployeeDAL();
            List<EmployeeBO> list = da.ReadEmployee();
            foreach (EmployeeBO bo in list)
                if (bo.ID == acNO)
                    return bo;
            return null;

        }

        public EmployeeBO getPIN(int login)
        {
            EmployeeDAL da = new EmployeeDAL();
            List<EmployeeBO> list = da.ReadEmployee();
            foreach (EmployeeBO bo in list)
                if (bo.Input == login)
                    return bo;
            return null;

        }


        public double getBlnc(string id, int pin)
        {
            EmployeeDAL DL = new EmployeeDAL();
            List<string> list = DL.Read(" ");
            for (int i = 0; i < list.Count; i++)
            {
                string[] data = list[i].Split(",");

                if (data[0] == id && System.Convert.ToInt32(data[2]) == pin)
                {
                    return System.Convert.ToDouble(data[5]);
                }
            }

            return 0;
        }

        public int Create_New_Account(EmployeeBO bo)
        {
            EmployeeDAL da = new EmployeeDAL();
            da.CreateAcc(bo);
            return bo.ID;
       
        }

        public void Delete_Existing_Account(int account_no, int accNo)
        {
            EmployeeDAL da = new EmployeeDAL();
            List<EmployeeBO> list = da.ReadEmployee();
            foreach (EmployeeBO b in list)
            {
                if (b.Account_no == account_no)
                {
                    Console.WriteLine($"{b.Name}");
                }

            }

            if (account_no == accNo)
            {
                EmployeeDAL dL = new EmployeeDAL();
               dL.delete();
            }
        }


        public void Update_Account_Information(EmployeeBO bo)
        {
            EmployeeDAL da = new EmployeeDAL();
            List<EmployeeBO> list = da.ReadEmployee();
            foreach (EmployeeBO b in list)
            {

            }
        }


        public void Search_For_Account(EmployeeBO bo)
        {
            EmployeeDAL da = new EmployeeDAL();
            List<EmployeeBO> list = da.ReadEmployee();
            foreach (EmployeeBO b in list)
            {

            }
        }


        public void View_Reports(EmployeeBO bo)
        {
            EmployeeDAL da = new EmployeeDAL();
            List<EmployeeBO> list = da.ReadEmployee();
            foreach (EmployeeBO b in list)
            {

            }

        }


        public void Exit()
        {

        }

        public List<EmployeeBO> ReadEmployee()
        {
            EmployeeDAL dal = new EmployeeDAL();
            return dal.ReadEmployee();
          
        }


        //--------------------------------------------------------------------------------------------



        public static bool FastCash(EmployeeBO Bo, int choice, decimal CurrentBlnc)
        {
            decimal amount = 0;

            if (choice == 1)
                amount = 500;

            else if (choice == 2)
                amount = 1000;

            else if (choice == 3)
                amount = 2000;

            else if (choice == 4)
                amount = 5000;

            else if (choice == 5)
                amount = 10000;

            else if (choice == 6)
                amount = 15000;

            else if (choice == 6)
                amount = 20000;

            if (CurrentBlnc >= amount)
            {
                EmployeeDAL ed = new EmployeeDAL();
                 ed.Fast_cash(Bo.ID, amount);
                return true;
            }

            return false;

        }


        public static bool NormalCash(int accNo, decimal amount, decimal CurrentBlnc)
        {
           

            if (CurrentBlnc >= amount)
            {
                decimal balance = CurrentBlnc - amount;
                EmployeeDAL de = new EmployeeDAL();
                 de.Normal_cash(accNo, amount);
                return true;
            }

            return false;

        }


    }
}
